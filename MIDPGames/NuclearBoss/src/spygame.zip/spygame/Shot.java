package spygame;

import java.io.*;
import java.lang.*;
import java.util.*;

import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.midlet.*;

import javax.microedition.media.*;
import javax.microedition.media.control.ToneControl;
import spygame.*;



public class Shot extends Entity {

	private Entity shooter;
		
	public Shot(Entity shooter) {
		spriteImage = Game.createImage("/shot2.png");
                sprite = new Sprite(spriteImage);	
                sprite.defineReferencePixel(4, 0);

                this.x = shooter.x;
		this.y = (shooter.crouching?36:12) + shooter.y;
		this.shooter = shooter;			
		this.setDirection(shooter.dir);
		this.vx = shooter.dir*8;
		if (shooter instanceof Agent) Agent.shotsFired++;	
                Game.canvas.play(SpyCanvas.shotTune);
	}
	
	void updateSprite() {
    	    sprite.setRefPixelPosition(this.x, this.y);
        }
        
	public void doMove() {
		this.x += vx;
		
		for (Enumeration e = level.entities.elements() ; e.hasMoreElements() ;) {
        	Entity ent = (Entity)e.nextElement();
        	if ((ent instanceof Shot)||(ent.equals(shooter))||((shooter instanceof Enemy)&&(ent instanceof Enemy))||(!ent.sprite.collidesWith(this.sprite, true))) continue;
        	
// if hits
        	System.out.println(this.shooter+" hits "+ent);
        	ent.injure(1);
        	if (ent.hitpoints<1) System.out.println(ent+" was shot by "+shooter);
//        	Game.showMessage(ent+" was shot by "+shooter);
        	if (shooter instanceof Agent) Agent.shotsHitted++;
        	this.kill();
		}

		
		if (validPos()) {
			if (vx!=0) sprite.nextFrame();
		} else this.kill();
	} 	
            
        boolean validPos() {
            return level.isXYFree(x +4 , y);
        }
}
