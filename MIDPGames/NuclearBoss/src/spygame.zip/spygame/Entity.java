package spygame;

import java.io.*;
import java.util.*;

import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.midlet.*;

import javax.microedition.media.*;
import javax.microedition.media.control.ToneControl;
import spygame.*;

public class Entity {
	
        public int[] WALKING_SEQUENCE = {0, 0,  1, 1, 2, 2, 3, 3};
    
        Level level;
    
	int reloadingPeriod = 12;
	
/** The Sprite that is the player */
        protected Sprite sprite;
	protected Image spriteImage;
	
	protected int x=200, y=200, vx = 0, vy = 0;
	
	protected int hitpoints;
		
	public int getX() {
		return (x+level.cell/2)/level.cell;
	}
	
	public int getY() {
		return 1+(y+level.cell/2)/level.cell;
	}
        
        public int getuY() {
		return (crouching?1:0) + (y+level.cell/2)/level.cell;
	}
	
	public void set(int x, int y) {
		this.x = x*Level.cell;
		this.y = (y-1)*Level.cell;
	}
	
	

	
	public Entity() {
 //           super(null, 1, 1);
            hitpoints = 10;
	
                
		System.out.println("new "+this);
///             System.out.println("entities = "+entities);
	}
	
	public void setupSkin(String imagename) {
            spriteImage = Game.createImage(imagename);
            sprite = new Sprite(spriteImage);	
        }
	
	boolean onFloor = false;
        boolean crouching = false;
        
	public void doMove() {
		// should never happend because it causes infinite loop 
                if (!validPos()) {
                    System.err.println(this + ": invalid pos");
                    return;
                }

		this.x += vx;
		if (validPos()) {
			if (vx!=0) sprite.nextFrame();
		} else {
			this.x -= vx;
			this.vx = 0;
			going = false;
		}
		
		this.y += vy;
		if (validPos()) {
			if (!onFloor) vy++;
			onFloor = false;
		} else {
			while (!validPos()) {
				if (vy>0) this.y--; else this.y++;
			};
			if (vy>0) onFloor = true;
//			this.y -= vy;
			vy = 1;
//			System.out.print(" invalid pos y ");
//			System.err.print(this+": on the floor");
		}
		
	} 	
	
	public void jump () {
		if (!onFloor) return;
		onFloor = false;
		this.vy = -11;
	}

        public void down () {
	//	if (onFloor) crouching = true;
        }
        
        boolean going = false;
        
	public void goLeft () {
		setDirection(-1);
		this.vx = -3;
	}

	public void goRight () {
		setDirection(1);
		this.vx = 3;
        }
	
	int reloading = 5;

	public void fire () {
		if (this.reloading>0) return;
		if (going) return;
                System.out.println(this+": fire");
		level.add(new Shot (this));
		this.reloading = reloadingPeriod;  
 	}
 	
 	public void injure (int damage) {
 		this.hitpoints -= damage;
 		System.out.println(this+" "+hitpoints+"hp left");
 		if (this.hitpoints<1) this.kill();

 	}
 	
/*	
	static final int DIR_RIGHT = 1;
	static final int DIR_LEFT = -1;
*/	
	protected int dir = 1;
	
	void setDirection (int dir) {
		this.dir=dir;
	}
	
	/**
     * Update the Sprite location from the board supplied position
     * @param dir the sprite is moving
     */
    void updateSprite() {
    	if (dir==-1) sprite.setTransform(Sprite.TRANS_MIRROR);
	if (dir==1) sprite.setTransform(Sprite.TRANS_NONE);
	sprite.setPosition(this.x, this.y);
        
    }

	boolean validPos () {
//		System.out.println(this+"verifying pos: "+!sprite.collidesWith(level.tiles, true));
//		return !sprite.collidesWith(level.tiles, true);
            Level l = level;
            
            return ((crouching||
                  (l.isXYFree(x+0, y+23)
                &&l.isXYFree(x+23, y+23)
                          
		&&l.isXYFree(x+0, y+0)
		&&l.isXYFree(x+23, y+0)))
                          
                &&l.isXYFree(x+0, y+24)
		&&l.isXYFree(x+23, y+24)
                          
                &&l.isXYFree(x+0, y+47)
		&&l.isXYFree(x+23, y+47)
            );
	}
	
	public void doWork () {
//		System.out.println(this+"'s turn:" +info());
//		System.out.print("sprite:"+sprite);
//		System.out.print(" .. moving");
		doMove();
		
		updateSprite();
		
                reloading--;
		going = false;
                crouching = false;

	}

	public String info () {
		return "["+getX()+"+"+dir+","+getY()/*+"]:["+vx+","+vy+"]:"+onFloor+":"+reloading*/+"]"+hitpoints;
	}
	
	protected void kill () {
//		entities.removeElement(this);
//		SpyCanvas.layers.remove(sprite);
            // TODO sprite.die
            level.kill(this);
            System.out.println(this+": was killed");
	}
	

}
