package spygame;

import javax.microedition.lcdui.*;


public abstract class AnimatedList extends Canvas {
    
    private int selectedIndex = 0;
    
    private String[] items = {"null"};
    
    private Image image = null;
    
    protected AnimatedList() {
        super();
        setFullScreenMode(true);    
    }
    
    /*
     * creates new AnimatedList Screen 
     * @PARAM name text written on the top of the screen
     * @PARAM items texts of items
     * @PARAM image image in the beckground 
     */
    public AnimatedList(String name, String[] items, Image image) {
        this();
        setItems(items);
        setImage(image);
    }
    
    void setItems(String[] items) {
        this.items = items;
        if (items.length>0) cellHeight = this.getHeight()/items.length; else cellHeight = 16;
        cellHeight = (cellHeight>16)?16:cellHeight;
 //       yShift = (this.getHeight() - cellHeight*items.length)/2;
        yShift = 30;
    }
    
    void setImage(Image image) {
        this.image = image;
    }
    
    int cellHeight;
    int yShift;
    
    public void paint(Graphics g) {
//        System.out.println("items: "+items);
        int width = getWidth(), height = getHeight();
        
        g.setColor(0);
        g.fillRect(0, 0, width, height);
        
        if (image!=null) g.drawImage(image, width, height, g.RIGHT|g.BOTTOM);
        
        g.setFont(Game.MENU_FONT);
        for (int i = 0; i<items.length; i++) {
            try {
                if (i==selectedIndex) g.setColor(0x00BB00); else g.setColor(0x00FF00);
                g.drawString(items[i], 5, yShift+i*cellHeight, g.LEFT|g.TOP);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (selectedIndex>-1) {
            g.setColor(0x00BB00);
            g.drawLine(0, yShift+selectedIndex*cellHeight, width, yShift+selectedIndex*cellHeight);
            g.drawLine(0, yShift+(selectedIndex+1)*cellHeight, width, yShift+(selectedIndex+1)*cellHeight);
        }
    }
    
    public void keyPressed(int key) {
        if (selectedIndex<0) itemSelected(selectedIndex);
        switch (getGameAction(key)) {
        case DOWN:
            if (selectedIndex<items.length-1) 
                selectedIndex++;
            else selectedIndex = 0;
            repaint();
        break;
        case UP:
            if (selectedIndex>0) 
                selectedIndex--;
            else selectedIndex = items.length - 1;
            repaint();
        break;
        case FIRE:
            itemSelected(selectedIndex);
            repaint();
        break;
        }    
    }
    
    public int getSelectedIndex() {
        return selectedIndex;
    }
    
    public void setSelectedIndex(int i) {
       selectedIndex = i;
       repaint();
    }
    
    abstract void itemSelected(int id);
/*    
    private CommandListener listener;
    
    public void setCommandListener(CommandListener l) {
        this.listener = l;
        super.setCommandListener(l);
    }
  */  
}
